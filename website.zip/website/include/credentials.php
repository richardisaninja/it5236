<?php

class Credentials {

    // Declare the credentials to the database
    public $servername = "it5236lambdatest.cpkbkuynuegf.us-east-1.rds.amazonaws.com";
    public $serverusername = "richard1";
    public $serverpassword = "Jeffery12_";
    public $serverdb = "richard1";

}

?>
